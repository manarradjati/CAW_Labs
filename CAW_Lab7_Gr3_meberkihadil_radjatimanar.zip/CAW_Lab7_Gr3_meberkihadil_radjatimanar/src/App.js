
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import MenuDisplay from './Components/MenuDisplay';
import Cart from './Components/Cart';
import Order from './Components/Order';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCartShopping, faHome, faListCheck } from '@fortawesome/free-solid-svg-icons';

const App = () => {
  const [cartItems, setCartItems] = useState([]); // State to store cart items

  // Function to add items to the cart
  const addToCart = (item) => {
    setCartItems((prevItems) => {
      // Check if item already exists in cart
      const existingItem = prevItems.find((i) => i.name === item.name);
      if (existingItem) {
        // If item exists, increase the quantity
        return prevItems.map((i) =>
          i.name === item.name ? { ...i, quantity: i.quantity + 1 } : i
        );
      }
      // Otherwise, add new item to the cart
      return [...prevItems, { ...item, quantity: 1 }];
    });
  };

  return (
    <Router>
      <div className="app-container">
        {/* Header Section */}
        <Header cartItems={cartItems} />
        {/* Routing */}
        <Routes>
          <Route path="/" element={<MenuDisplay addToCart={addToCart} />} />
          <Route path="/cart" element={<Cart cartItems={cartItems} />} />
          <Route path="/orders" element={<Order cartItems={cartItems} />} />
        </Routes>
      </div>
    </Router>
  );
};

// Header Component
const Header = ({ cartItems }) => {
  const navigate = useNavigate(); // Hook for navigation

  const handleHomeClick = () => {
    navigate('/');
  };

  const handleBasketClick = () => {
    navigate('/cart'); // Navigate to the Cart page
  };
  const handleOrdersClick = () => {
    navigate('/orders'); // Navigate to the Orders page
  };

  return (
    <div className="header">
      <FontAwesomeIcon
        icon={faHome}
        className="icon"
        onClick={handleHomeClick} // Handle click on Home icon
      />
      <FontAwesomeIcon
      icon={faListCheck}
      className='icon'
      onClick={handleOrdersClick} // Handle click on Orders icon
      />
      <div className="basket-container" onClick={handleBasketClick}>
        <FontAwesomeIcon icon={faCartShopping} className="icon" />
        {cartItems.length > 0 && (
          <span className="cart-count">{cartItems.length}</span>
        )}
      </div>
    </div>
  );
};

export default App;