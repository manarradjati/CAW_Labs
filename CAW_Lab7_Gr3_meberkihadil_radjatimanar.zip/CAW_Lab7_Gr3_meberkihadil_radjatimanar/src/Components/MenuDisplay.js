
import React from 'react';
import MenuItem from './MenuItem';

const Styles = {
    div: {
    margin: '10px 10px',
    },
    h2: {
    fontSize: '25px',
    color: '#8D0B41',
    margin: '5px 0',
    },
};

const MenuDisplay = ({ addToCart }) => {
const menuCategories = [
    {category: 'Pizza', items: [{ name: 'Pepperoni Pizza', price: 10 }, { name: 'Veggie Pizza', price: 8 }, ],},
    {category: 'Sandwich', items: [{ name: 'Grilled Cheese', price: 5 }, { name: 'Chicken Sandwich', price: 7 }, ], }
    ];

return (
    <div style={{margin:'30px 0'}}>
    {menuCategories.map((category) => (
        <div style={Styles.div} key={category.category}>
        <h2 style={Styles.h2}>{category.category}</h2>
        {category.items.map((item, index) => (
            <MenuItem key={index} item={item}  onAddToCart={addToCart}/> // Pass addToCart function to MenuItem 
        ))}
        </div>
    ))}
    </div>
);
};

export default MenuDisplay;