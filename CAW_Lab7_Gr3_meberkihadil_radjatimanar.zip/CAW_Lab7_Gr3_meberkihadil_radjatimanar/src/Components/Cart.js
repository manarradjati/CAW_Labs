import React from 'react';

const Cart = ({ cartItems }) => {
// Calculate the total price
const totalPrice = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
const Styles = {
    div: {
        padding: '10px 10px'
    },
    ul: {
        padding: '0 20px',
        listStyle: 'auto'
    },
    li: {
        margin: '5px 0'
    },
    span: {
        margin: '0 3px',
        fontSize: '18px'
    }
}


return (
    <div className="cart-container" style={Styles.div}>
    <h2 style={{fontSize:'25px', fontWeight:'bold'}}>YOUR CART</h2>
    {cartItems.length === 0 ? (
        <p>Your cart is empty</p>
    ) : (
        <div>
        <ul className="cart-item-list" style={Styles.ul}>
            {cartItems.map((item, index) => (
            <li key={index} className="cart-item" style={Styles.li}>
                <span style={{margin:'0 3px', fontSize:'18px', fontWeight:'500'}}>{item.name}</span><br/>
                {<span style={Styles.span}>Quantity: {item.quantity}</span>}
                {<span style={Styles.span}>Price: ${item.price}</span>}
                <span style={Styles.span}>Total: ${item.price * item.quantity}</span>
            </li>
            ))}
        </ul>
        <div className="cart-total">
            <h3>TOTAL: ${totalPrice.toFixed(2)}</h3>
        </div>
        </div>
    )}
    </div>
);
};

export default Cart;