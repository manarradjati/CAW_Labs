import React from 'react';

const Orders = ({ cartItems }) => {
  // Generate a summary paragraph for the order
const generateOrderSummary = () => {
    if (cartItems.length === 0) {
    return "Your cart is empty.";
    }

const itemDetails = cartItems.map(
    (item) => `${item.quantity}x ${item.name} ($${item.price} each)`
    );

    return `You have ordered the following items: ${itemDetails.join(", ")}. The total cost is $${calculateTotal().toFixed(2)}.`;
};

// Calculate the total cost of the order
const calculateTotal = () =>
    cartItems.reduce((total, item) => total + item.price * item.quantity, 0);

return (
    <div className="orders-page" style={{padding:'20px 20px'}}>
    <h1 style={{fontSize:'22px'}}>YOUR ORDER SUMMARY</h1>
    <p style={{textAlign:'justify', fontSize:'18px'}}>{generateOrderSummary()}</p>
    </div>
);
};

export default Orders;