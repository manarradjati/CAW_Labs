
import React from 'react';

const Styles = {
  div: {
    display: 'flex',
    justifyContent: 'space-between',
    margin: '20px 0',
  },
  p: {
    fontWeight: '500',
    fontSize: '20px',
  },
};

const MenuItem = ({ item, onAddToCart }) => {
  return (
    <div style={Styles.div}>
      <p style={Styles.p}>{item.name} - ${item.price}</p>
      <button onClick={() => onAddToCart(item)}>Add to Cart</button>
    </div>
  );
};

export default MenuItem;
