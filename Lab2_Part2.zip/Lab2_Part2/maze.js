window.onload = function() {
    let boundaries = document.querySelectorAll(".boundary");
    let start = document.getElementById("start");
    let end = document.getElementById("end");
    let status = document.getElementById("status");
    let gameActive = false;
    let gameLost = false;

    // Turn all boundaries red 
    boundaries.forEach(function(boundary) {
        boundary.addEventListener("mouseover", function() {
            if (gameActive) {
                boundaries.forEach(function(bound) {
                    bound.classList.add("youlose");
                });
                status.textContent = "You lose!";
                status.style.color = "red";
                gameLost = true; 
                gameActive = false; 
            }
        });
    });

    // Display a "You win!" or "You already lost!"
    end.addEventListener("mouseover", function() {
        if (gameActive && !gameLost) {
            status.textContent = "You win!";
            status.style.color = "green";
            
            gameActive = false; 
        } else if (gameLost) {
            status.textContent = "You already lost!";  
            status.style.color = "red";
        }
    });

    //Restartable maze
    start.addEventListener("click", function() {
        boundaries.forEach(function(bound) {
            bound.classList.remove("youlose");
        });
        status.textContent = "Move your mouse over the 'S' to begin.";
        status.style.color = "black";
        gameActive = true; 
        gameLost = false;   
    });

    // Disallow cheating
    document.addEventListener("mousemove", function(e) {
        let mazeRect = document.getElementById("maze").getBoundingClientRect();
        if (gameActive && (e.clientX < mazeRect.left || e.clientX > mazeRect.right || e.clientY < mazeRect.top || e.clientY > mazeRect.bottom)) {
            boundaries.forEach(function(bound) {
                bound.classList.add("youlose");
            });
            status.textContent = "You lose!";
            status.style.color = "red";
            gameLost = true; 
            gameActive = false; 
        }
    });
};
